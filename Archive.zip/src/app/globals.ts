import { Injectable } from '@angular/core';

@Injectable()
export class Globals {
  isDropdownOpen = false;
  activateMenu = false;
  apiCounter = 0;
}