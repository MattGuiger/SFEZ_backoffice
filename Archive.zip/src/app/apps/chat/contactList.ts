import { Chat } from './chat';
export class contactList {

    public id: number;

    public imagePath: string;
    public name: string;
    public signature: string;
    public time: string;

    public chats: Chat[];


}
