import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { SpinnerComponent } from '../shared/spinner.component';


@NgModule({
  declarations: [
    // SpinnerComponent
  ],
  imports: [
  ],
  exports:[
    // SpinnerComponent
  ]
})
export class SharedModule {


 }
