import { Component } from '@angular/core';
@Component({
  templateUrl: './size.component.html'
})
export class TablesizeComponent {}
