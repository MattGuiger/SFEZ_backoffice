import { Component } from '@angular/core';
@Component({
  templateUrl: 'checkout.component.html'
})
export class CheckoutComponent {}
