import { Component } from '@angular/core';
@Component({
  templateUrl: 'details.component.html'
})
export class DetailsComponent {}
