import { Component } from '@angular/core';

@Component({
  selector: 'app-form-actions',
  templateUrl: './actions.component.html',
  styleUrls: ['./actions.component.css']
})
export class FormactionsComponent {}
