import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manager-edit',
  templateUrl: './manager-edit.component.html',
  styleUrls: ['./manager-edit.component.css']
})
export class ManagerEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
