import { Component } from '@angular/core';
@Component({
  templateUrl: 'simpleline.component.html'
})
export class SimplelineComponent {}
